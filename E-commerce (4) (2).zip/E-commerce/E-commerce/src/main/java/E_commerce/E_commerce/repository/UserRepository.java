package E_commerce.E_commerce.repository;

import E_commerce.E_commerce.model.MyAppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<MyAppUser, Long> {
    Optional<MyAppUser> findByUsername(String username); // Ensure this exists
    Optional<MyAppUser> findByEmail(String email); // Add this method
}
