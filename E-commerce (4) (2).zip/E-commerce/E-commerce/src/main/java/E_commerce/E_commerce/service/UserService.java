package E_commerce.E_commerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private JavaMailSender emailSender;

    public void sendPasswordResetLink(String email) {
        // Generate a unique token and create the reset link
        String token = UUID.randomUUID().toString(); // Example token generation
        String resetLink = "http://localhost:8085/reset-password?token=" + token;

        // Send email
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Password Reset Request");
        message.setText("To reset your password, click the link below:\n" + resetLink);
        emailSender.send(message);

        // You might want to save the token in the database for validation later
    }

    public void resetPassword(String newPassword, String confirmPassword) {
        // Validate the new password (e.g., check if they match)
        if (!newPassword.equals(confirmPassword)) {
            throw new IllegalArgumentException("Passwords do not match!");
        }
        // Here you would typically update the password in the database
        // Example: userRepository.updatePassword(userId, newPassword);
    }
}
