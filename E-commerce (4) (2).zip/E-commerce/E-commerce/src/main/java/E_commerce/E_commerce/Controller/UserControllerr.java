package E_commerce.E_commerce.Controller;

import E_commerce.E_commerce.service.UserServicee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.ByteArrayInputStream;
import java.io.IOException;

@Controller
public class UserControllerr {

    @Autowired
    private UserServicee userServicee;

    @GetMapping("/downloadPdf")
    public ResponseEntity<InputStreamResource> downloadPdf() throws IOException {
        ByteArrayInputStream pdfStream = userServicee.generatePdf();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=user_data.pdf");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)
                .body(new InputStreamResource(pdfStream));
    }
}
