package E_commerce.E_commerce.security;

import E_commerce.E_commerce.service.MyAppUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final MyAppUserService appUserService;

    @Autowired
    public SecurityConfig(MyAppUserService appUserService) {
        this.appUserService = appUserService;
    }

    // Bean to load user details from MyAppUserService
    @Bean
    public UserDetailsService userDetailsService() {
        return appUserService;
    }

    // Authentication provider using DAO
    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(appUserService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    // Password encoder for encoding user passwords
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Security configuration filter chain
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(AbstractHttpConfigurer::disable) // Disable CSRF for simplicity (you can enable it later)
                .formLogin(httpForm -> {
                    httpForm.loginPage("/req/login").permitAll(); // Custom login page
                    httpForm.successHandler(authenticationSuccessHandler()); // Custom success handler
                })
                .logout(logout -> {
                    logout
                            .logoutUrl("/logout") // Custom logout URL
                            .logoutSuccessUrl("/req/login?logout") // Redirect to login with logout message
                            .invalidateHttpSession(true) // Invalidate session on logout
                            .deleteCookies("JSESSIONID") // Delete session cookies
                            .permitAll(); // Allow everyone to access logout
                })
                .authorizeHttpRequests(registry -> {
                    registry.requestMatchers("/", "/index", "/static/css/**", "/js/**").permitAll(); // Public pages
                    registry.requestMatchers("/req/signup", "/forgot-password", "/resetPasswordRequest", "/reset-password").permitAll(); // Allow reset password and signup pages
                    registry.requestMatchers("/about").authenticated(); // Restrict the About page to authenticated users
                    registry.requestMatchers("/admin/**").hasRole("ADMIN"); // Admin pages restricted to ADMIN role
                    registry.anyRequest().authenticated(); // Any other request requires authentication
                })
                .oauth2Login(oauth2 -> {
                    oauth2.loginPage("/req/login").permitAll(); // OAuth2 login
                    oauth2.userInfoEndpoint(userInfoEndpointConfig ->
                            userInfoEndpointConfig.userService(oAuth2UserService()) // Custom OAuth2 user service
                    );
                })
                .build();
    }

    // Success handler for handling post-login actions
    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new CustomAuthenticationSuccessHandler();
    }

    // Custom OAuth2 user service
    @Bean
    public OAuth2UserService<OAuth2UserRequest, OAuth2User> oAuth2UserService() {
        return new DefaultOAuth2UserService(); // Use the default service or a custom one if needed
    }
}
