package E_commerce.E_commerce.Controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.util.stream.Collectors;

@Controller
public class ContentController {

    @GetMapping("/req/login")
    public String login() {
        return "login"; // Returns the login.html Thymeleaf template
    }

    @GetMapping("/req/signup")
    public String signup() {
        return "signup"; // Returns the signup.html Thymeleaf template
    }

    @GetMapping("/home")
    public String home(Model model, Principal principal) {
        String username = principal.getName();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(", "));
        model.addAttribute("username", username);
        model.addAttribute("roles", roles);
        return "home"; // Returns the home.html Thymeleaf template
    }

    @GetMapping("/about")
    public String about() {
        return "about"; // Returns the about.html Thymeleaf template
    }
}

