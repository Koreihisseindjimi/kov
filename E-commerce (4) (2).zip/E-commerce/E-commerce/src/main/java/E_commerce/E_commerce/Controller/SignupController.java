package E_commerce.E_commerce.Controller;



import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class SignupController {

    @PostMapping(value = "/signup", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @ResponseBody
    public String handleSignup(
            @RequestParam("firstName") String firstName,
            @RequestParam("lastName") String lastName,
            @RequestParam("email") String email,
            @RequestParam("phoneNumber") String phoneNumber,
            @RequestParam("idNumber") String idNumber,
            @RequestParam("dob") String dob,
            @RequestParam("password") String password) {

        // You can now perform validations, save user info to the database, etc.
        // Example message returned
        return "Signup successful! Welcome, " + firstName + " " + lastName + "!";
    }
}

